<?php 
  session_start();
  if (isset($_SESSION["user"])) {
    header("Location: home.php");
    exit();
  }
?>
<!DOCTYPE html>
<html>
<head>
  <title>Home | Aptaki</title>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css" integrity="sha512-1PKOgIY59xJ8Co8+NE6FZ+LOAZKjy+KY8iq0G4B3CyeY6wYHN3yt9PW0XpSriVlkMXe40PTKnXrLnZ9+fkDaog==" crossorigin="anonymous" />
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body id="home">
  <?php include 'navigation.php'; ?>

  <div id="home" class="intro route bg-image" style="background-image: url(https://cdn0.weddingwire.in/vendor/2983/3_2/960/jpeg/royal-broz-event-and-wedding-planner-4_15_232983-157303598179327.jpeg)">
    <div class="overlay-itro"></div>
    <div class="intro-content display-table">
      <div class="table-cell">
        <div class="container">
          <h1 class="intro-title h1">DREAM ORGANIZER</h1>
          <!-- <p class="intro-subtitle"><span class="text-slider-items">Web Developement,Web Designing,App Development,Interior designing,creative designing, graphic designing,e-designing</span><strong class="text-slider"></strong></p> -->
        </div>
      </div>
    </div>

  </div>

  <div class="preloader">
    <div class="loader"></div>
  </div>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

  <!-- <script src="js/jquery.counterup.min.js"></script>
  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script> -->
  <script src="js/main.js"></script>
</body>
</html>
