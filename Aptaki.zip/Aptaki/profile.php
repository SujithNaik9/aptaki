<?php 
  include 'config.php';
  session_start();
  if (!isset($_SESSION["user"])) {
    header("Location: index.php");
    exit();
  }
  $sql="SELECT * FROM accounts WHERE username='$_SESSION[user]'";
  $result=$conn->query($sql);
  $row=$result->fetch_assoc();
  if ($row["photo"]!=null || $row["photo"]!='') {
    $dp=$row["photo"];
  }else{
    $dp="default.jpg";
  }
  $id=$row["uid"];
  $username=$row["username"];
  $email=$row["email"];
  $mobile=$row["mobile"];
  $fullname=$row["fullname"];
  $sex=$row["sex"];
?>
<!DOCTYPE html>
<html>
<head>
  <title>Profile | Aptaki</title>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css" integrity="sha512-1PKOgIY59xJ8Co8+NE6FZ+LOAZKjy+KY8iq0G4B3CyeY6wYHN3yt9PW0XpSriVlkMXe40PTKnXrLnZ9+fkDaog==" crossorigin="anonymous" />
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body id="home" class="grad-purple">
  <?php include 'navigation.php'; ?>

  <div class="container" style="margin-top: 100px; ">
  <div class="row flex-lg-nowrap">
    <div class="col">
      <div class="row">
        <div class="col mb-3">
          <div class="card">
            <div class="card-body">
              <div class="e-profile">
                <div class="row">
                  <div class="col-12 col-sm-auto mb-3">
                    <div class="mx-auto" style="width: 140px;">
                      <div class="d-flex justify-content-center align-items-center rounded" style="height: 140px; background-color: rgb(233, 236, 239);">
                        <!-- <span style="color: rgb(166, 168, 170); font: bold 8pt Arial;">140x140</span> -->
                        <img id="preview" style="width: 100%;height: 100%" src="ProfilePhoto/<?php echo $dp; ?>">
                      </div>
                    </div>
                  </div>
                  <div class="col d-flex flex-column flex-sm-row justify-content-between mb-3">
                    <div class="text-center text-sm-left mb-2 mb-sm-0">
                      <h4 class="pt-sm-2 pb-1 mb-0 text-nowrap"></h4>
                      <div class="mt-2">
                        <form id="form1" method="post" action="workspace.php" enctype="multipart/form-data">
                          <button class="btn btn-primary btn-file" >
                            <i class="fa fa-fw fa-camera"></i>
                            <span>Choose Photo</span>
                            <input type="hidden" name="pid" value="<?php echo $id ?>">
                            <input id="choosepic" type="file" name="ProfilePhoto" accept=".jpg,.jpeg,.png" onChange="document.getElementById('preview').src = window.URL.createObjectURL(this.files[0])"/>
                          </button>
                        </form>
                      </div>
                    </div>
                    </div>
                </div>
                <ul class="nav nav-tabs">
                  <li class="nav-item"><a href="" class="active nav-link">Settings</a></li>
                </ul>
                <div class="tab-content pt-3">
                  <div class="tab-pane active">
                    <form id="form2" class="form" method="post" action="workspace.php" enctype="multipart/form-data">
                      <div class="row">
                        <div class="col">
                          <div class="row">
                            <div class="col">
                              <div class="form-group">
                                <label>Full Name</label>
                                <input class="form-control" type="text" name="name" placeholder="Enter Fullname" value="<?php echo $fullname; ?>" required>
                              </div>
                            </div>
                            <div class="col">
                              <div class="form-group">
                                <label>Username</label>
                                <input class="form-control" type="text" name="uname" placeholder="Enter Username" value="<?php echo $username; ?>" required>
                              </div>
                            </div>
                          </div>
                          <div class="row">
                            <div class="col">
                              <div class="form-group">
                                <label>Mobile Number</label>
                                <input class="form-control" type="tel" name="mobile" placeholder="Enter valid Mobile number" value="<?php echo $mobile; ?>" required>
                              </div>
                            </div>
                          </div>
                          <div class="row">
                            <div class="col">
                              <div class="form-group">
                                <label>Email</label>
                                <input class="form-control" type="text" name="email" placeholder="Enter valid Email address" value="<?php echo $email; ?>" required>
                              </div>
                            </div>
                          </div>
                          <div class="row">
                            <div class="col">
                              <div class="form-group">
                                <label>Gender</label>
                                <select class="form-control" name="gender">
                                  <option value="" disabled>Choose Gender</option>
                                  <option value="M" <?php if($sex=="M") echo "selected" ?>>Male</option>
                                  <option value="F" <?php if($sex=="F") echo "selected" ?>>Female</option>
                                </select>
                                <!-- <input class="form-control" name="gender" type="text" value="<?php echo $gender ?>" > -->
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col">
                          <div class="mb-2"><b>Change Password</b></div>
                          <div class="row">
                            <div class="col">
                              <div class="form-group">
                                <label>Current Password</label>
                                <input class="form-control" type="password" name="oldpwd" placeholder="Enter Current password">
                              </div>
                            </div>
                          </div>
                          <div class="row">
                            <div class="col">
                              <div class="form-group">
                                <label>New Password</label>
                                <input class="form-control" type="password" name="newpwd" placeholder="Enter New Password">
                              </div>
                            </div>
                            <div class="col">
                              <div class="form-group">
                                <label>Confirm <span class="d-none d-xl-inline">Password</span></label>
                                <input class="form-control" type="password" name="conpwd" placeholder="Re-enter New Password"></div>
                            </div>
                          </div>
                        </div>
                        
                      </div>
                      <div class="row">
                        <div class="col d-flex justify-content-end">
                          <input type="hidden" name="profile_id" value="<?php echo $id; ?>">
                          <input type="hidden" name="profileSubmit">
                          <button id="profileSubmit" class="btn btn-primary" type="submit">Save Changes</button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      <div class="col-12 col-md-3 mb-3">
        <div class="card mb-3">
          <div class="card-body">
            <div class="px-xl-3">
              <a href="logout.php" style="text-decoration: none;"><button class="btn btn-block btn-danger">
                <i class="fa fa-sign-out"></i>
                <span>Logout</span>
              </button></a>
            </div>
          </div>
        </div>
        <div class="card">
          <div class="card-body">
            <h6 class="card-title font-weight-bold">Bookings</h6>
            <p class="card-text">Check your current or previous bookings.</p>
            <a href="book.php">
              <button type="button" class="btn btn-primary">Bookings</button></a>
          </div>
        </div>
      </div>
    </div>

  </div>
</div>
</div>

  <div class="preloader">
    <div class="loader"></div>
  </div>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script src="js/main.js"></script>
  <script type="text/javascript">

    $("#choosepic").change(function(e){
      e.preventDefault();
      $("#form1").submit();
    });

    $("#form1").submit(function(e){
      e.preventDefault();
      data=new FormData(this);
      
      $.ajax({
        type: $(this).attr('method'),
        url: $(this).attr('action'),
        data: data,
        cache:false,
        contentType: false,
        processData: false,
        success: function (data) {
          console.log(data);
              if (data==1) {
                $("#message").show().removeClass("bg-danger").addClass("bg-success");
                $("#message").text("Profile Photo updated").fadeOut(4500);
              }
              else{
                $("#message").show().removeClass("bg-success").addClass("bg-danger");
                $("#message").text("Profile Photo couldn't be Updated").fadeOut(4500);
              }
        },
      });
    });

    $("#form2").submit(function(e){
      e.preventDefault();
      $.ajax({
        type: $(this).attr('method'),
        url: $(this).attr('action'),
        data:new FormData(this),
        cache:false,
        contentType: false,
        processData: false,
        beforeSend: function(){ $("#profileSubmit").html('Loading...');},
        success: function (data) {
              console.log(data);
              if (data==1) {
                $("#message").show().removeClass("bg-danger").addClass("bg-success");
                $("#message").text("Profile updated").fadeOut(4500);
              }
              else if(data==9){
                $("#message").show().removeClass("bg-success").addClass("bg-danger");
                $("#message").text("Current Password Entered doesn't match with the Old Password").fadeOut(4500);
              }
              else if(data==8){
                $("#message").show().removeClass("bg-success").addClass("bg-danger");
                $("#message").text("New Password Entered doesn't match with the Confirm Password").fadeOut(4500);
              }
              else{
                $("#message").show().removeClass("bg-success").addClass("bg-danger");
                $("#message").text("Profile couldn't be Updated").fadeOut(4500);
              }
        },
        complete: function(){ $("#profileSubmit").html('Save Changes');}
        });
    });
  </script>
</body>
</html>
