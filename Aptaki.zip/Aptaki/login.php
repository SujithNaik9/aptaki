<?php 
  session_start();
  if (isset($_SESSION["user"])) {
    header("Location: home.php");
    exit();
  }
?>
<!DOCTYPE html>
<html>
<head>
  <title>Dream Organizer | Login</title>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css" integrity="sha512-1PKOgIY59xJ8Co8+NE6FZ+LOAZKjy+KY8iq0G4B3CyeY6wYHN3yt9PW0XpSriVlkMXe40PTKnXrLnZ9+fkDaog==" crossorigin="anonymous" />
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body id="home" class="grad-purple">
  <?php include 'navigation.php'; ?>

  <!-- <div id="home" class="intro route bg-image" style="background-image: url(https://mindlercareerlibrarynew.imgix.net/17A-Event_Management.png)">
    <div class="overlay-itro"></div>
    <div class="intro-content display-table">
      <div class="table-cell">
        <div class="container">
          <h1 class="intro-title">APTAKI PRODUCTIONS</h1> -->
          <!-- <p class="intro-subtitle"><span class="text-slider-items">Web Developement,Web Designing,App Development,Interior designing,creative designing, graphic designing,e-designing</span><strong class="text-slider"></strong></p> -->
        <!-- </div>
      </div>
    </div> -->
    <!-- <div class="container-down justify-content-center">
      <a href="#about-point" class="js-scroll" id="about-point">
        <div class="chevron"></div>
        <div class="chevron"></div>
        <div class="chevron"></div>
      </a>
    </div> -->
  <!-- </div> -->

  <!-- <div class="preloader">
    <div class="loader"></div>
  </div> -->
  <div class="container mt-5">
   <div class="row">
     <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
       <div class="card shadow card-signin my-5">
         <div class="card-body">
           <h2 class="card-title text-center h2 mt-3 mb-4">Welcome Back!</h2>
           <form class="form-signin" action="workspace.php" method="post">
             <div class="form-label-group my-4">
               <input type="text" id="inputEmail" name="email" class="form-control" placeholder="Email or username or mobile" required autofocus>
             </div>

             <div class="form-label-group my-4">
               <input type="Password" id="inputPassword" name="pwd" class="form-control" placeholder="Password" required>
               <!-- <label for="inputPassword">Password</label> -->
             </div>

             <!-- <div class="custom-control custom-checkbox mb-3">
               <input type="checkbox" class="custom-control-input" id="customCheck1">
               <label class="custom-control-label" for="customCheck1">Remember password</label>
             </div> -->
             <button class="btn btn-lg btn-primary btn-block text-uppercase" type="submit" name="logsub">Login</button>
             <hr class="my-4">
             <p class="text-center">Don't have an account? <a href="signup.php">Signup</a></p>
             <p class="text-center">Admin? <a href="./Dashboard/login.php">Admin Login</a></p>

             <!-- <button class="btn btn-lg btn-google btn-block text-uppercase" type="submit"><i class="fab fa-google mr-2"></i> Sign in with Google</button>
             <button class="btn btn-lg btn-facebook btn-block text-uppercase" type="submit"><i class="fab fa-facebook-f mr-2"></i> Sign in with Facebook</button> -->
           </form>
         </div>
       </div>
     </div>
   </div>
 </div>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <!-- <script src="js/jquery.counterup.min.js"></script>
  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script> -->
  <script src="js/main.js"></script>
</body>
</html>
