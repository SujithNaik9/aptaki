<?php
	session_start();
	unset($_SESSION["user"]);
	session_destroy();
    echo "<script>alert('Successfully Logged out');window.location.href='login.php';</script>";
    exit();
?>