<?php
  include 'config.php'; 
  session_start();
  if (!isset($_SESSION["admin"])) {
    header("Location: login.php");
    exit();
  }
?>
<!DOCTYPE html>
<html>
<head>
  <title>Dashnoard | Aptaki</title>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css" integrity="sha512-1PKOgIY59xJ8Co8+NE6FZ+LOAZKjy+KY8iq0G4B3CyeY6wYHN3yt9PW0XpSriVlkMXe40PTKnXrLnZ9+fkDaog==" crossorigin="anonymous" />
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
  <div class="d-flex" id="wrapper">
    <?php include 'navigation.php'; ?>
    <div id="page-content-wrapper">
      <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom justify-content-md-end">
        <button class="btn d-md-none" id="menu-toggle"><span class="navbar-toggler-icon"></span></button>
          <a href="logout.php" class="btn"><i class="fas fa-sign-in-alt"></i></a>
      </nav>
      <div class="container-fluid mt-5">
        <div class="d-sm-flex align-items-center justify-content-center mb-4 mt-4">
          <h1 class="h2 mb-0 text-gray-800">All Bookings</h1>
        </div>
        <table class="table table-bordered table-responsive w-100 d-block d-md-table" >
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Name</th>
              <th scope="col">Phone</th>
              <th scope="col">Event Name</th>
              <th scope="col">Event Venue</th>
              <th scope="col">Event City</th>
              <th scope="col">Event Date</th>
            </tr>
          </thead>
          <tbody>
            <?php
              $sql="SELECT e.name,a.mobile,b.venue,b.from_date,b.place,a.fullname as uname FROM booking b,events e,accounts a where b.eid=e.eid AND b.uid=a.uid ORDER BY booked_on DESC";
              $result=$conn->query($sql);
              $i=1;
              while($row=$result->fetch_assoc()){ ?>
                <tr>
                  <th scope="row"><?php echo $i ?></th>
                  <td><?php echo $row["uname"] ?></td>
                  <td><?php echo $row["mobile"] ?></td>
                  <td><?php echo $row["name"] ?></td>
                  <td><?php echo $row["venue"] ?></td>
                  <td><?php echo $row["place"] ?></td>
                  <td><?php echo $row["from_date"] ?></td>
                </tr>
                <?php
                $i++;
              }


            ?>
           <!--  <tr>
              <th scope="row">1</th>
              <td>Mark</td>
              <td>Otto</td>
              <td>@mdo</td>
            </tr>
            <tr>
              <th scope="row">2</th>
              <td>Jacob</td>
              <td>Thornton</td>
              <td>@fat</td>
            </tr>
            <tr>
              <th scope="row">3</th>
              <td>Larry the Bird</td>
              <td>Thornton</td>
              <td>@twitter</td>
            </tr> -->
          </tbody>
        </table>
              </div>
    </div>
  </div>



  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <!-- <script src="js/main.js"></script> -->
  <script>
    $("#menu-toggle").click(function(e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });
    $('#eposter').change(function() {
      var file = $('#eposter')[0].files[0].name;
      $("#fileName").text(file);
    });
  </script>
</body>
</html>
