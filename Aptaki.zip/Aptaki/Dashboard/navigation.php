<div class="bg-light border-right" id="sidebar-wrapper">
      <div class="sidebar-heading">Admin</div>
      <div class="list-group list-group-flush">
        <a target="_blank" href="http://localhost/Aptaki" class="list-group-item list-group-item-action bg-light">View site</a>
        <a href="index.php" class="list-group-item list-group-item-action bg-light">Bookings</a>
        <a href="event.php" class="list-group-item list-group-item-action bg-light">Add Events</a>
        <a href="service.php" class="list-group-item list-group-item-action bg-light">Add Services</a>
        <a href="admin.php" class="list-group-item list-group-item-action bg-light">Add Admin</a>
<!--         <a href="bookings.php" class="list-group-item list-group-item-action bg-light">Add Bookings</a>
 -->        <!-- <a href="#" class="list-group-item list-group-item-action bg-light">Profile</a>
        <a href="#" class="list-group-item list-group-item-action bg-light">Status</a> -->
      </div>
    </div>