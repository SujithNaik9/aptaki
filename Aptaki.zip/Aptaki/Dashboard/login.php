<?php 
  session_start();
  if (isset($_SESSION["admin"])) {
    header("Location: index.php");
    exit();
  }
?>
<!DOCTYPE html>
<html>
<head>
  <title>Dashboard | Aptaki</title>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css" integrity="sha512-1PKOgIY59xJ8Co8+NE6FZ+LOAZKjy+KY8iq0G4B3CyeY6wYHN3yt9PW0XpSriVlkMXe40PTKnXrLnZ9+fkDaog==" crossorigin="anonymous" />
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

  <div class="container mt-5">
   <div class="row">
     <div class="col-sm-9 col-md-7 col-lg-5 mx-auto mt-5">
       <div class="card shadow card-signin my-5">
         <div class="card-body">
           <h2 class="card-title text-center h2 mt-3 mb-4">Welcome Back!</h2>
           <form class="form-signin" action="workspace.php" method="post">
            <hr class="my-4">
             <div class="form-label-group my-4">
               <input type="text" id="inputEmail" name="email" class="form-control" placeholder="Email or mobile" required autofocus>
             </div>
             <div class="form-label-group my-4">
               <input type="password" id="inputPassword" name="pwd" class="form-control" placeholder="Password" required>
             </div>
             <button class="btn btn-lg btn-primary btn-block text-uppercase" type="submit" name="logsub">Login</button>
             <hr class="my-4">
           </form>
           <p class="text-center"> <a href="../home.php">Home</a></p>
         </div>
       </div>
     </div>
   </div>
 </div>
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <!-- <script src="js/main.js"></script> -->
</body>
</html>
