<?php 
  session_start();
  if (!isset($_SESSION["admin"])) {
    header("Location: login.php");
    exit();
  }
?>
<!DOCTYPE html>
<html>
<head>
  <title>Dashnoard | Aptaki</title>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css" integrity="sha512-1PKOgIY59xJ8Co8+NE6FZ+LOAZKjy+KY8iq0G4B3CyeY6wYHN3yt9PW0XpSriVlkMXe40PTKnXrLnZ9+fkDaog==" crossorigin="anonymous" />
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
  <div class="d-flex" id="wrapper">
    <?php include 'navigation.php'; ?>
    <div id="page-content-wrapper">
      <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom justify-content-md-end">
        <button class="btn d-md-none" id="menu-toggle"><span class="navbar-toggler-icon"></span></button>
          <a href="logout.php" class="btn"><i class="fas fa-sign-in-alt"></i></a>
      </nav>
      <div class="container-fluid">
        <div class="d-sm-flex align-items-center justify-content-center mb-4 mt-4">
          <h1 class="h2 mb-0 text-gray-800">Add Service</h1>
        </div>
        <div class="container row shadow pt-5 pb-5 justify-content-center mx-auto">
          <div class="col-md-11">
            <form action="workspace.php" method="post" enctype="multipart/form-data">
              <div class="form-group">
                <label for="ename" class="h6 mb-3">Event Name</label>
                <input id="sname" class="form-control" type="text" placeholder="Enter Event Name" name="sname" autocomplete="off" required>
              </div>
              <div class="form-group text-center">
                <button class="btn btn-primary text-uppercase" type="submit" name="ssub">ADD</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>



  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <!-- <script src="js/main.js"></script> -->
  <script>
    $("#menu-toggle").click(function(e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });
    $('#eposter').change(function() {
      var file = $('#eposter')[0].files[0].name;
      $("#fileName").text(file);
    });
  </script>
</body>
</html>
