<?php
	include "config.php";
  	session_start();

  	if(isset($_POST["logsub"])) {
	    $sql="SELECT * FROM admin WHERE name='$_POST[email]' AND password='$_POST[pwd]' OR  email='$_POST[email]' AND password='$_POST[pwd]' OR phone='$_POST[email]' AND password='$_POST[pwd]'";
	    $result=$conn->query($sql);
	    if($row=$result->fetch_assoc()){
	      $_SESSION["admin"]=$row["email"];
	      echo "<script>alert('Successfully Logged in');window.location.href='index.php';</script>";
	      exit();
	    }
	    else {
	      $conn->error;
	      echo "<script>alert('Could not Login, Try again after sometime');window.location.href='login.php';</script>";
	      exit();
	    }
	}

	if (isset($_POST["esub"])) {
		$title=$_POST["ename"];
		$disc=$_POST["edisc"];
		$cost=$_POST["ecost"];
		// $title=$_POST["ename"];
		$sql="SELECT * FROM events WHERE eid=(SELECT MAX(eid) FROM events)";
		$result=$conn->query($sql);
		$row=$result->fetch_assoc();
		$eid=$row["eid"]+1;
		if (!empty($_FILES["eposter"]["name"])) {
			$file = $_FILES['eposter']['name'];
			$path = pathinfo($file);
			$ext = $path['extension'];
			$filename = $eid.".".$ext;
			$temp_name = $_FILES['eposter']['tmp_name'];
			$path_filename_ext = "../poster/".$filename;
			if(move_uploaded_file($temp_name,$path_filename_ext)){
				$sql="INSERT INTO events(name,disc,picture,min_price) VALUES('$title','$disc','$filename','$cost')";
				if ($conn->query($sql)) {
					echo "<script>alert('Successfully Added New Event');window.location.href='index.php';</script>";
	      			exit();
				}
				else{
					unlink($path_filename_ext);
					echo "<script>alert('Failed to Add New Event');window.location.href='index.php';</script>";
	      			exit();
				}
			}
			else{
				echo "<script>alert('Failed to Add New Event');window.location.href='index.php';</script>";
	      		exit();
			}
		}
	}

	if (isset($_POST["asub"])){
		$name=$_POST["aname"];
		$email=$_POST["Email"];
		$phone=$_POST["phno"];
		$password=$_POST["pswd"];
		$sql="INSERT INTO admin(name,email,phone,password) VALUES('$name','$email','$phone','$password')";
		if($conn->query($sql)){
			echo "<script>alert('Successfully Added New Admin');window.location.href='admin.php';</script>";
	      	exit();
		}
		else{
			echo "<script>alert('Failed to Add New Admin');window.location.href='admin.php';</script>";
	      	exit();
		}
	}

	if (isset($_POST["ssub"])){
		$sername=$_POST["sname"];
		$sql="INSERT INTO services(name) VALUES('$sername')";
		if($conn->query($sql)){
			echo "<script>alert('Successfully Added New service');window.location.href='service.php';</script>";
	      	exit();
		}
		else{
			echo "<script>alert('Failed to Add New service');window.location.href='service.php';</script>";
	      	exit();
		}
	}
?>