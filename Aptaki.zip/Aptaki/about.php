<?php 
  session_start();
  // if (!isset($_SESSION["user"])) {
  //   header("Location: index.php");
  //   exit();
  // }
?>
<!DOCTYPE html>
<html>
<head>
  <title>About | Dream Organizer</title>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css" integrity="sha512-1PKOgIY59xJ8Co8+NE6FZ+LOAZKjy+KY8iq0G4B3CyeY6wYHN3yt9PW0XpSriVlkMXe40PTKnXrLnZ9+fkDaog==" crossorigin="anonymous" />
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body id="home" class="grad-purple">
  <?php include 'navigation.php'; ?>

  

  <div class="mx-auto" style="width: 90% !important;margin-top: 100px;">
    
    <div class="row">
      <div class="col-lg-5 align-self-center">
        <div class="card card-block" >
          <div class="card-body">
            <img id="poster" class="w-100 h-900" src="http://www.mindzproductionz.co.in/images/slide-7.jpg">
          </div>
        </div>
      </div>
      <div class="col-lg-7">
        <h3 class="h1 mb-4 text-center text-light">About Us</h3>
        <div class="card">
          <!-- <div class="card-title px-4 pt-3">
            <h2 id="title" class="h2"></h2>
          </div> -->
          <div class="card-body px-5 py-3">
            <p  class="text-justify" id="discription">
                  <span class="text-uppercase">DREAM ORGANIZER</span> is an event logistics and marketing company which was formed back in 202. The company offers A-Z event planning services from a team of experienced and energetic event planners, suppliers, venues and more. One of the main reasons behind the success of Event Planner is the fact that the team does not charge fees to its clients! With the number of events we organise, Event Planner Ltd does not need to add exorbitant fees and mark-ups to make its profit margins. This ensures that our clients list, which is constantly growing, make regular use of our services.<br>
                  There is no fee. There is no mark-up!<br>
                  The Event Planner team does not charge any fees to its clients*. Yes, this might sound strange. However, the company earns its profits through its suppliers, with whom a very strong relationship has been built. This does not mean that the costs are up-marked to make up for the fee. On the contrary, they are less than it would cost a company when booking directly. We know it sounds too good to believe, but over the years this formula has helped the Event Planner team become the success story they are today. This has not in any way reduced the level of professionalism with which the services are carried, as shown by the large number of local and international clients,  who work with us on a regular basis.<br>
                  In a nutshell, you pay no fee, pay your supplier less and have a professional team handling all your loose ends. Sounds too good, but it is true! You can check out our clients as testimonials<br>
                  The Event Planner team is made up of a mix of people. James and Ilona take care of corporate events. Josette is the wedding guru. Nicole is the creative one. Sergio is the merchandise expert. In addition to this group of people, a large support team helps out in everything the company does, in office work to on-site logistics planning. One thing we can truly say about our team is that we are very passionate about our job!

            </p>
          </div>
        </div>
      </div>
    </div>
  </div>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script src="js/main.js"></script>
  <script type="text/javascript">

    $(".view").click(function(){
      var id = $(this).data('id');
      $.ajax({
        url:"workspace.php",
        type:"post",
        data:{viewEvent:"true",id:id},
        dataType: 'json',
        success:function(data){
          // $("#discription").html(id);
          if (data.status==1) {
            $("#poster").attr("src","poster/"+data.poster);
            $("#title").html(data.title);
            $("#discription").html(data.disc);
            $("#price").html("&#x20B9;"+data.price+".");
            $("#eventID").val(data.id);
          }
          else if(data.status==0){
           window.location.href="event.php";
          }
        }
      });
    });

    $("#bookbtn").click(function(){
      // console.log($("#eventID").val());
      var id=$("#eventID").val();
      window.location.href="booking.php?id="+id;
    });
  </script>
</body>
</html>
