<?php
  $db="aptaki";
  $host="localhost";
  $user="root";
  $password="";
  $conn= new mysqli($host, $user, $password, $db);
  if($conn->connect_error) {
    print("Database Connection failed".$conn->connect_error);
  }
 ?>
