<?php
  include "config.php";
  session_start();
  if(isset($_POST["sigsub"])) {
    $sql="INSERT INTO accounts(username, password, fullname, email, mobile) VALUES('$_POST[uname]','$_POST[pwd]','$_POST[fname]','$_POST[email]','$_POST[mob]')";
    if($conn->query($sql)) {
      $_SESSION["user"]=$_POST["uname"];
      echo "<script>alert('Successfully Registered');window.location.href='home.php';</script>";
      exit();
    }
    else {
      echo "<script>alert('Could not register, Try again after sometime');window.location.href='signup.php';</script>";
      exit();
    }
  }

  if(isset($_POST["logsub"])) {
    $sql="SELECT * FROM accounts WHERE username='$_POST[email]' AND password='$_POST[pwd]' OR email='$_POST[email]' AND password='$_POST[pwd]' OR mobile='$_POST[email]' AND password='$_POST[pwd]'";
    // $admin_1="SELECT * FROM admin WHERE name='$_POST[email]' AND password='$_POST[pwd]' OR email='$_POST[email]' AND password='$_POST[pwd]' OR phone='$_POST[email]' AND password='$_POST[pwd]'";
    $result=$conn->query($sql);
    // $result_admin = $conn->query($admin_1);
    if($row=$result->fetch_assoc()){
      $_SESSION["user"]=$row["username"];
      echo "<script>alert('Successfully Logged in');window.location.href='home.php';</script>";
      exit();
    }
    // else if($row=$result_admin->fetch_assoc()){
    //   $_SESSION["user"]=$row["name"];
    //   echo "<script>alert('Successfully Logged in');window.location.href='./Dashboard/admin.php';</script>";
    //   exit();
    // }
    else {
      $conn->error;
      echo "<script>alert('Could not Login, Try again after sometime');window.location.href='login.php';</script>";
      exit();
    }
  }

  if (isset($_FILES["ProfilePhoto"]["name"])) {
    $file = $_FILES['ProfilePhoto']['name'];
    $path = pathinfo($file);
    $ext = $path['extension'];
    $filename = $_POST["pid"].".".$ext;
    $temp_name = $_FILES['ProfilePhoto']['tmp_name'];
    $path_filename_ext = "ProfilePhoto/".$filename;
    $sql="UPDATE accounts SET photo='$filename' WHERE uid='$_POST[pid]'";
    if ($conn->query($sql)) {
      if(move_uploaded_file($temp_name,$path_filename_ext))
        echo 1;
      else
        echo 0;
    }
    else
      echo 0;
  }

  if (isset($_POST["profileSubmit"])) {
    $profile_id=$_POST["profile_id"];
    $name=$_POST["name"];
    $mobile=$_POST["mobile"];
    $email=$_POST["email"];
    $uname=$_POST["uname"];
    $gender=$_POST["gender"];
    $oldpwd=$_POST["oldpwd"];
    $newpwd=$_POST["newpwd"];
    $conpwd=$_POST["conpwd"];
    $sql="SELECT * FROM accounts WHERE uid='$profile_id'";
    $result=$conn->query($sql);
    $row=$result->fetch_assoc();
    if($newpwd!=null || $newpwd!=''){
      if ($row["password"]!=$oldpwd) {
        echo 9;
      }
      else{
        if ($newpwd!=$conpwd) {
          echo 8;
        }
        else{
          $sql="UPDATE accounts SET username='$uname',fullname='$name',email='$email',password='$conpwd',mobile='$mobile',sex='$gender' WHERE uid='$profile_id'";
            if ($conn->query($sql)) {
              $_SESSION["user"]=$uname;
              echo 1;
            }
            else{
              echo 0;
            }
        }
      }
    }
    else{
      $sql="UPDATE accounts SET username='$uname',fullname='$name',email='$email',mobile='$mobile',sex='$gender' WHERE uid='$profile_id'";
      if ($conn->query($sql)) {
        $_SESSION["user"]=$uname;
        echo 1;
      }
      else{
        echo 0;
      }
    }
  }

  if (isset($_POST["viewEvent"])) {
     $id=$_POST["id"];
     $sql="SELECT * FROM events WHERE eid='$id'";
     $result=$conn->query($sql);
     $data=array();
     if ($row=$result->fetch_assoc()) {
       $data["status"]=1;
       $data["id"]=$row["eid"];
       $data["title"]=$row["name"];
       $data["disc"]=$row["disc"];
       $data["poster"]=$row["picture"];
       $data["price"]=$row["min_price"];
     }
     else{
      $data["status"]=0;
     }
     echo json_encode($data);
  }

  if (isset($_POST["BookSub"])) {
    $EId=$_POST["EId"];
    $Evenue=$_POST["Evenue"];
    $Eplace=$_POST["Eplace"];
    $Estate=$_POST["Estate"];
    $Ecountry=$_POST["Ecountry"];
    $Esdate=$_POST["Esdate"];
    $Eedate=$_POST["Eedate"];
    $Estime=$_POST["Estime"];
    $Eetime=$_POST["Eetime"];
    $Eservice=$_POST["Eservice"];
    $Ebudget=$_POST["Ebudget"];
    $sql="SELECT * FROM accounts WHERE username='$_SESSION[user]'";
    $result=$conn->query($sql);
    $row=$result->fetch_assoc();
    $sql="INSERT INTO booking(uid,eid,from_date,to_date,start_time,end_time,venue,place,state,country,budget) VALUES('$row[uid]','$EId','$Esdate','$Eedate','$Estime','$Eetime','$Evenue','$Eplace','$Estate','$Ecountry','$Ebudget')";
    if($conn->query($sql)){
      $sql="SELECT * FROM booking WHERE bid=(SELECT MAX(bid) FROM booking)";
      $result=$conn->query($sql);
      $row=$result->fetch_assoc();
      $Callsql="CALL book_services('$row[bid]','$Eservice')";
      if ($conn->query($Callsql)) {
        echo "<script>alert('Successfully booked the event');window.location.href='event.php';</script>";
        exit();
      }
      else{
        echo "<script>alert('Failed to book ');window.location.href='event.php';</script>";
        exit();
      }
    }
    else{
      echo "<script>alert('Failed to book the event');window.location.href='event.php';</script>";
      exit();
    }
  }
?>
