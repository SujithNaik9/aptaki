<?php 
  include 'config.php';
  if (isset($_SESSION["user"])) {
    $sql="SELECT * FROM accounts WHERE username='$_SESSION[user]'";
    $result=$conn->query($sql);
    $row=$result->fetch_assoc();
    if ($row["photo"]!=null || $row["photo"]!='') {
      $dp=$row["photo"];
    }else{
      $dp="default.jpg";
    }
    $name=$row["username"];
  }
  else{
    $dp="default.jpg";
  }
?>
<div class="alert white-text center" id="message"></div>
<nav class="navbar navbar-expand-md navbar-dark bg-mat shadow fixed-top p-1">
    <div class="container">
      <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#dual-collapse2">
              <span> </span>
              <span> </span>
              <span> </span>
          </button>
          <a class="navbar-brand text-secondary font-weight-bold" href="../Aptaki">DREAM ORGANIZER</a>
          <div class="navbar-collapse collapse order-1 order-md-0" id="dual-collapse2" >
            <ul class="navbar-nav">
                <li class="nav-item">
                <a href="../Aptaki" class="nav-link">Home</a>
              </li>
              <!-- <li class="nav-item">
                <a href="#" class="nav-link">Gallery</a>
              </li> -->
              <li class="nav-item">
                <a href="event.php" class="nav-link">Events</a>
              </li>
              <li class="nav-item">
                <a href="about.php" class="nav-link">About</a>
              </li>
                <!-- <li class="nav-item">
                <a href="#" class="nav-link">News</a>
              </li> -->
            </ul>
        </div>
        <div class="menu">
            <ul class="navbar-nav float-right">
                <li class="nav-item dropdown mr-2">
                    <a class="nav-link" href="#" id="cart" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><!-- <i class="fas fa-user-circle" style="font-size: 1.3rem"></i> -->
                      <div style="width: 30px; height: 30px;overflow: hidden;border-radius: 100%;">
                        <img class="w-100 h-100" src="profilePhoto/<?php echo $dp ?>">
                      </div>
                    </a>
                    <ul class="dropdown-menu drop-menu" aria-labelledby="navbarDropdown">
                      <!-- <a class="dropdown-item" href="#"><i class="fas fa-shopping-cart mr-3"></i> Your Cart</a> -->
                      <?php 
                        if (isset($_SESSION["user"])) { ?>
                          <li class="dropdown-item" href="#">Welcome, <b><?php echo $name ?></b></li>
                          <li><hr></li>
                          <li><a class="dropdown-item" href="book.php"><i class="fas fa-box-open mr-3"></i> Bookings</a></li>
                          <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user-circle mr-3"></i> Your Account</a></li>
                          <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-in-alt mr-3"></i> Logout</a></li>
                      <?php }else{ ?>
                          <li><a class="dropdown-item" href="login.php"><i class="fas fa-sign-in-alt mr-3"></i> Signin/Login</a></li>
                      <?php } ?>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
  </nav>