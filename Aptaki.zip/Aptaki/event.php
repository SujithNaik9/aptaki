<?php 
  session_start();
  // if (!isset($_SESSION["user"])) {
  //   header("Location: index.php");
  //   exit();
  // }
?>
<!DOCTYPE html>
<html>
<head>
  <title>Events | Aptaki</title>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css" integrity="sha512-1PKOgIY59xJ8Co8+NE6FZ+LOAZKjy+KY8iq0G4B3CyeY6wYHN3yt9PW0XpSriVlkMXe40PTKnXrLnZ9+fkDaog==" crossorigin="anonymous" />
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body id="home" class="grad-purple">
  <?php include 'navigation.php'; ?>

  <!-- <div id="home" class="intro route bg-image" style="background-image: url(https://mindlercareerlibrarynew.imgix.net/17A-Event_Management.png)">
    <div class="overlay-itro"></div>
    <div class="intro-content display-table">
      <div class="table-cell">
        <div class="container">
          <h1 class="intro-title h1">APTAKI PRODUCTIONS</h1>
          <p class="intro-subtitle"><span class="text-slider-items">Web Developement,Web Designing,App Development,Interior designing,creative designing, graphic designing,e-designing</span><strong class="text-slider"></strong></p>
        </div>
      </div>
    </div>
  </div> -->

  <div class="mx-auto" style="width: 90% !important;margin-top: 100px;">
    <h3 class="h1 mt-5 mb-4 text-center text-light">EVENTS</h3>
    <div class="row">
      <!-- <div class="col-md-3 col-sm-6 mt-3">
        <div class="card shadow ">
          <div class="card-body" style="height: 230px">
            <img class="w-100 h-100" src="poster/poster.jpg">
          </div>
          <div class="card-footer text-center">
            <h4 class="card-title text-truncate">Photography</h4>
            <button class="w-75 btn btn-secondary">Book</button>
          </div>
        </div>
      </div>
      <div class="col-md-3 col-sm-6 mt-3">
        <div class="card shadow ">
          <div class="card-body" style="height: 230px">
            <img class="w-100 h-100" src="https://blogmedia.evbstatic.com/wp-content/uploads/wpmulti/sites/8/2019/10/How-to-organise-music-concert.jpg">
          </div>
          <div class="card-footer text-center">
            <h4 class="card-title text-truncate">Concerts</h4>
            <button class="w-75 btn btn-secondary">Book</button>
          </div>
        </div>
      </div>
      <div class="col-md-3 col-sm-6 mt-3">
        <div class="card shadow ">
          <div class="card-body" style="height: 230px">
            <img class="w-100 h-100" src="https://tourandtravelblog.com/public_html/tourandtravelblog/wp-content/uploads/2020/04/6-Most-Popular-wedding-destination.jpg">
          </div>
          <div class="card-footer text-center">
            <h4 class="card-title text-truncate">Wedding</h4>
            <button class="w-75 btn btn-secondary">Book</button>
          </div>
        </div>
      </div> -->
      <?php
        $sql="SELECT * FROM events";
        $result=$conn->query($sql);
        while($row=$result->fetch_assoc()){
      ?>
        <div class="col-md-3 col-sm-6 mt-3">
          <div class="card shadow ">
            <div class="card-body" style="height: 230px">
              <img class="w-100 h-100" src="poster/<?php echo $row['picture'] ?>">
            </div>
            <div class="card-footer text-center">
              <h4 class="card-title text-truncate"><?php echo $row['name'] ?></h4>
              <button class="w-75 btn btn-secondary view" data-id="<?php echo $row['eid'] ?>" data-toggle="modal" data-target="#myModal">View</button>
            </div>
          </div>
        </div>
      <?php
        }
      ?>
    </div>
  </div>

  <div class="modal fade" id="myModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <div class="row">
            <div class="col-lg-5">
              <div class="card">
                <div class="card-body">
                  <img id="poster" class="w-100 h-100" src="">
                </div>
              </div>
            </div>
            <div class="col-lg-7">
              <div class="card">
                <div class="card-title px-4 pt-3">
                  <h2 id="title" class="h2"></h2>
                </div>
                <div class="card-body">
                  <p id="discription"></p>
                  <p>
                    <span><b>Minimum Budget:</b></span>
                    <span id="price"></span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer justify-content-center">
          <input type="hidden" name="eid" id="eventID">
          <button id="bookbtn" type="button" class="btn btn-secondary">Book</button>
          <button type="button" class="btn btn-primary" data-dismiss="modal">Cancel</button>
        </div>
      </div>
    </div>
  </div>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script src="js/main.js"></script>
  <script type="text/javascript">

    $(".view").click(function(){
      var id = $(this).data('id');
      $.ajax({
        url:"workspace.php",
        type:"post",
        data:{viewEvent:"true",id:id},
        dataType: 'json',
        success:function(data){
          // $("#discription").html(id);
          if (data.status==1) {
            $("#poster").attr("src","poster/"+data.poster);
            $("#title").html(data.title);
            $("#discription").html(data.disc);
            $("#price").html("&#x20B9;"+data.price+".");
            $("#eventID").val(data.id);
          }
          else if(data.status==0){
           window.location.href="event.php";
          }
        }
      });
    });

    $("#bookbtn").click(function(){
      // console.log($("#eventID").val());
      var id=$("#eventID").val();
      window.location.href="booking.php?id="+id;
    });
  </script>
</body>
</html>
