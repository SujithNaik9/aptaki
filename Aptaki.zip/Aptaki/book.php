<?php 
  include 'config.php';
  session_start();
  if (!isset($_SESSION["user"])) {
    header("Location: index.php");
    exit();
  }
  $sql="SELECT * FROM accounts WHERE username='$_SESSION[user]'";
  $result=$conn->query($sql);
  $row=$result->fetch_assoc();
  if ($row["photo"]!=null || $row["photo"]!='') {
    $dp=$row["photo"];
  }else{
    $dp="default.jpg";
  }
  $id=$row["uid"];
  $username=$row["username"];
  $email=$row["email"];
  $mobile=$row["mobile"];
  $fullname=$row["fullname"];
  $sex=$row["sex"];
?>
<!DOCTYPE html>
<html>
<head>
  <title>Profile | Aptaki</title>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css" integrity="sha512-1PKOgIY59xJ8Co8+NE6FZ+LOAZKjy+KY8iq0G4B3CyeY6wYHN3yt9PW0XpSriVlkMXe40PTKnXrLnZ9+fkDaog==" crossorigin="anonymous" />
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body id="home" class="grad-purple">
  <?php include 'navigation.php'; ?>
  <div class="container" style="margin-top: 100px; ">
    <div class="d-sm-flex align-items-center justify-content-center mb-4 mt-4">
          <h1 class="h2 mb-0 text-white">All Bookings</h1>
        </div>
    <table class="table table-bordered table-dark table-responsive w-100 d-block d-md-table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Event Name</th>
      <th scope="col">Event Venue</th>
      <th scope="col">Event Date</th>
    </tr>
  </thead>
  <tbody>
    <?php 
    $sql="SELECT b.venue,b.from_date,e.name FROM booking b, events e WHERE b.eid=e.eid AND b.uid='$id'";
    $result=$conn->query($sql);
    $result1=$conn->query($sql);
    if($row1=$result1->fetch_assoc()){
      $i=1;
      while($row=$result->fetch_assoc()){?>

        <tr>
          <th scope="row"><?php echo $i ?></th>
          <td><?php echo $row["name"] ?></td>
          <td><?php echo $row["venue"] ?></td>
          <td><?php echo $row["from_date"] ?></td>
        </tr>

      <?php 
          $i++;
        }
      }
      else{ ?>
          <tr>
            <td colspan="4" class="text-center">No previous booking</td>
          </tr>
     <?php }
    ?>

    
  </tbody>
</table>
              </div>
    </div>
  </div>

    
  </div>
  

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script src="js/main.js"></script>
  <script type="text/javascript">

   
  </script>
</body>
</html>
