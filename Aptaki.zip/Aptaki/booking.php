<?php
  include 'config.php'; 
  session_start();
  if (!isset($_SESSION["user"])) {
    header("Location: login.php");
    exit();
  }
  if (isset($_GET["id"])) {
    $id=$_GET["id"];
    $sql="SELECT * FROM events WHERE eid='$id'";
    $result=$conn->query($sql);
    $row=$result->fetch_assoc();
    $title=$row["name"];
  }
?>
<!DOCTYPE html>
<html>
<head>
  <title>Aptaki | Signup</title>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css" integrity="sha512-1PKOgIY59xJ8Co8+NE6FZ+LOAZKjy+KY8iq0G4B3CyeY6wYHN3yt9PW0XpSriVlkMXe40PTKnXrLnZ9+fkDaog==" crossorigin="anonymous" />
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body id="home" class="grad-purple">
  <?php include 'navigation.php'; ?>

  <div class="container mt-5">
   <div class="row">
     <div class="col-sm-10 col-md-8 col-lg-6 mx-auto">
       <div class="card shadow card-signin my-5">
         <div class="card-body">
           <h2 class="card-title text-center h2 mt-3 mb-4">Book Your Event!</h2>
           <form class="form-signin" action="workspace.php" method="post">
             <div class="form-label-group my-4">
               <input type="text" class="form-control" placeholder="Enter Full Name" value="<?php echo ucfirst($title) ?>" required disabled>
             </div>
             <div class="form-label-group my-4">
               <input type="text" id="Evenue" name="Evenue" class="form-control" placeholder="Enter event venue" required autofocus>
             </div>
             <div class="form-label-group my-4">
               <input type="text" id="Eplace" name="Eplace" class="form-control" placeholder="Enter Place" required>
             </div>
             <div class="form-label-group my-4">
               <input type="text" id="Estate" name="Estate" class="form-control" placeholder="Enter State" required>
             </div>
             <div class="form-label-group my-4">
               <input type="text" id="Ecountry" name="Ecountry" class="form-control" placeholder="Enter Country" required>
             </div>
             <div class="form-row"> 
               <div class="form-group col-md-6">
                 <label for="inputPassword">Enter start-date</label>
                 <input type="date" id="Esdate" name="Esdate" class="form-control" placeholder="Enter start date" required>
               </div>
               <div class="form-group col-md-6">
                 <label for="inputPassword">Enter end-date</label>
                 <input type="date" id="Eedate" name="Eedate" class="form-control" placeholder="Enter end date" required>
               </div>
             </div>
             <div class="form-row"> 
               <div class="form-group col-md-6">
                 <label for="inputPassword">Enter start-time</label>
                 <input type="time" id="Estime" name="Estime" class="form-control" placeholder="Enter start time" required>
               </div>
               <div class="form-group col-md-6">
                 <label for="inputPassword">Enter end-time</label>
                 <input type="time" id="Eetime" name="Eetime" class="form-control" placeholder="Enter end time" required>
               </div>
             </div>
             <div class="form-label-group">
               <select class="form-control" id="Eservice" name="Eservice" required>
                 <option value="selected disabled">Choose services required for the event</option>
                 <?php
                    $sql="SELECT * FROM services";
                    $result=$conn->query($sql);
                    while($row=$result->fetch_assoc()){ ?>
                      <option value="<?php echo $row['sid']; ?>"><?php echo $row["name"]; ?></option>
                    <?php 
                    }
                 ?>
               </select>
             </div>
             <div class="form-label-group my-4">
               <input type="text" id="Ebudget" name="Ebudget" class="form-control" placeholder="Enter event budget" required>
             </div>
             <input type="hidden" name="EId" value="<?php echo $id ?>">
             <button class="btn btn-lg btn-primary btn-block text-uppercase" name="BookSub" type="submit">Book</button>
             <hr class="my-4">
           </form>
         </div>
       </div>
     </div>
   </div>
 </div>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script src="//code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/typed.js/2.0.5/typed.min.js" integrity="sha512-1KbKusm/hAtkX5FScVR5G36wodIMnVd/aP04af06iyQTkD17szAMGNmxfNH+tEuFp3Og/P5G32L1qEC47CZbUQ==" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.min.js" integrity="sha512-CEiA+78TpP9KAIPzqBvxUv8hy41jyI3f2uHi7DGp/Y/Ka973qgSdybNegWFciqh6GrN2UePx2KkflnQUbUhNIA==" crossorigin="anonymous"></script>
 <!-- <script src="js/jquery.counterup.min.js"></script>
  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>-->
  <script src="js/main.js"></script>
</body>
</html>
